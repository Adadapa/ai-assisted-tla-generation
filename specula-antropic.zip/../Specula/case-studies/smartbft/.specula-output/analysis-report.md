# Analysis Report: hyperledger-labs/SmartBFT

## Coverage Statistics

- **Total git commits analyzed**: 487 touching `internal/bft/`
- **Bug-fix commits identified**: 29 substantive (28 confirmed + 1 revert that is informative)
- **GitHub issues collected**: 101 total; 43+ deeply read (full comment threads)
- **Confirmed bug issues/PRs**: 21 confirmed; 1 open unfixed (#628)
- **Excluded as false positives**: ~60 (dependency bumps, feature requests, documentation, test flakiness)

---

## Phase 1: Reconnaissance

### Core Files

| File | LOC | Role |
|------|-----|------|
| `internal/bft/viewchanger.go` | 1363 | View-change state machine: StartViewChange → ViewData → NewView → ViewChanged |
| `internal/bft/view.go` | 1093 | Per-round consensus: PrePrepare → Prepare → Commit → Decide |
| `internal/bft/controller.go` | 977 | Top-level coordinator: routes messages, drives sync, manages leader token |
| `internal/bft/util.go` | 574 | `getLeaderID`, `CheckInFlight`, vote set, in-flight data |
| `internal/bft/heartbeatmonitor.go` | 414 | Independent goroutine: sends leader heartbeats, detects follower timeout |
| `internal/bft/requestpool.go` | 567 | Request deduplication, timeout, pool management |
| `internal/bft/state.go` | 247 | WAL persistence: save/restore proposal + view-change state |
| `internal/bft/statecollector.go` | 147 | State collection from peers (for sync): f+1 quorum of matching responses |
| `internal/bft/batcher.go` | 92 | Assembles request batches for proposals |
| `internal/bft/sched.go` | 248 | Serial task scheduler used by HeartbeatMonitor |

### Architecture Notes

**Three independent goroutines**:
1. `Controller.run()` — processes all consensus messages sequentially
2. `ViewChanger.run()` — processes all view-change messages sequentially
3. `HeartbeatMonitor.run()` — runs on ticks, sends heartbeats (leader) or checks timeout (follower)

**Communication between goroutines** — via channels:
- `Controller` → `ViewChanger`: `abortViewChan` (abort current view), `informChan` (new view number after sync)
- `ViewChanger` → `Controller`: `ViewChanged(view, seq)` call (notifies new view entered)
- `HBM` → `Controller`: `OnHeartbeatTimeout(view, leaderID)` callback, `Sync()` callback
- `Controller` → `HBM`: `ChangeRole(view, leaderID, follower)` command via `commandChan`

**Leader identity computation** (SmartBFT-specific):
```go
LeaderID = getLeaderID(view, N, nodesList, leaderRotation, decisionsInView, decisionsPerLeader, blacklist)
```
This computed leader (not elected) is a key deviation from Raft/PBFT. Any stale input to this function produces the wrong leader.

**Delivery architecture** (evolved through multiple bug-fix PRs):
- `Controller.decide()` calls `c.Deliver.Deliver()` → `MutuallyExclusiveDeliver.Deliver()` → updates `Checkpoint`
- `ViewChanger.deliverDecision()` calls `v.Application.Deliver()` which is also `MutuallyExclusiveDeliver` (set in `consensus.go:440`) → updates `Checkpoint`
- `syncLock` serializes concurrent sync + view-change delivery paths

---

## Phase 2: Bug Archaeology

### 2.1 Critical Historical Bugs (Fixed)

#### C1: Double Delivery via Sync × View Change (4 variants)

Four independently discovered variants of the same family, all safety violations.

| Commit | PR | Summary |
|--------|----|----|
| `0ac141d` | #484 | Sync commits proposal; view change also commits same proposal. + stale in-flight after sync |
| `154c866`/`31f018a` | #560 | One delivery path missing Checkpoint write → double delivery on re-entry; reverted, superseded |
| `d9182ed` | #553 | Double delivery with genesis edge case (`0 >= 0` comparison) + wrong commit path in ViewChanger |
| `57f434c` | #570 | Comprehensive fix: running view not stopped before ViewData; checkpoint not updated on old-view sync |

Root cause summary: Multiple delivery code paths (2 in Controller, 2 in ViewChanger) each with their own Checkpoint update. Any path missing the update leaves a window for re-delivery. Fix: `MutuallyExclusiveDeliver` wrapper with `syncLock`.

#### C2: Decide + AbortView Deadlock (PR #622, commit `eb005ee`, HIGH)

- `View.decide()` sends to unbuffered `decisionChan` then blocks on `deliverChan`
- `Controller.run()` calls `abortView()` → `View.Abort()` → `wg.Wait()`
- Both goroutines block on each other. Confirmed with 69-minute-old goroutines in production Hyperledger Fabric v3.0.0.
- Fix: `decisionChan` made buffered (capacity 1); `AbortChan()` method added to View.

#### C3: Fork View Change (commit `6833de8`, HIGH)

- Nodes diverged on which view to enter. Nodes at view N+1 dropped view-change messages for view N from lagging nodes. Lagging nodes could never gather quorum.
- Fix: `nextViews` tracking; node at N+1 re-broadcasts view-change for lagging peers.

#### C4: CheckInFlight Condition B Never Fires (commit `420a802`, HIGH)

- Counter `noInFlightPreparedCount` never incremented → condition B (`quorum agrees no in-flight`) never true → view change stalls when there genuinely is no in-flight.
- Fix: Added `noInFlightPreparedCount++`.

#### C5: DecisionsInView Reset to Zero in Same-Height Sync (commit `62e7161`, HIGH)

- `newDecisionsInView` update guarded by `latestDecisionSeq > controllerSequence`. When same-height sync (no advance), `newDecisionsInView = 0` passed to `changeView`, resetting counter. Next proposal fails `view.go:577` ("Expected decisions in view 0 but got N"). Recovery sync loop: ~10 seconds per cycle. Production orderers fall permanently behind.
- Fix: Move `DecisionsInView` update to a separate `if latestDecisionMetadata != nil` block, decoupled from sequence advance condition. Most recent significant fix (April 2026).

### 2.2 High Historical Bugs (Fixed)

| Commit | Component | Summary |
|--------|-----------|---------|
| `cd14de6` | controller, view | Data race: GetMetadata + leader token acquisition race on restart |
| `2a0557b` | controller | Leader stuck in propose after restart (spin loop on empty batch) |
| `30764c3` | viewchanger | Panic: in-flight one behind latest after committing during view change |
| `90e9fbf` | controller | Spurious view change: request timers not reset on leader rotation |
| `86be08d` | requestpool | Go loop-variable capture in RestartTimers (all timers fire for last request) |
| `36cac46` | view | Nil pointer panic in MembershipNotifier (optional field not nil-checked) |
| `2d10ba0` | util, view | Wrong field in AuxiliaryData + wrong leader blacklist offset |
| `d15594f` | state | WAL recovery logic inverted: both conditions were backwards (node never recovers) |
| `63307ca` | view | Sequence incremented before decision delivered; vote reset premature |
| `9fd5bc5` | view | Race on vote set swap without lock during concurrent registerVote |
| `227a30d` | view | Abort() hangs if waiting for pre-prepare channel |
| `039d00e` | controller | Race: view Start() called after lock released |
| `c5a7847` | requestpool | Deadlock: semaphore acquired while holding pool mutex |
| `79fd150` | requestpool | Deadlock: predicate called while holding pool mutex (lock inversion) |
| `e5e760c` | requestpool | Data race: NextRequests returns internal slice reference |
| `15e8114` | requestpool | Duplicate txid after sync |
| `6833de8` | viewchanger | Fork view change: lagging nodes can't gather quorum |

### 2.3 Bug Hotspot Analysis

| Component | Bug-fix commits | Severity peaks |
|-----------|----------------|----------------|
| `viewchanger.go` | 8 | 4 CRITICAL (double delivery), 1 HIGH (fork VC), 1 HIGH (in-flight panic) |
| `controller.go` | 7 | 3 CRITICAL (double delivery), 2 HIGH (deadlocks), 2 HIGH (restart bugs) |
| `requestpool.go` | 5 | 3 HIGH (deadlocks + race) |
| `view.go` | 4 | 1 HIGH (vote race), 1 HIGH (sequence order) |
| `state.go` | 1 | 1 HIGH (recovery logic inverted) |
| `heartbeatmonitor.go` | 1 | 1 HIGH (leader stops heartbeat after rotation) |

ViewChanger + Controller account for **15 of 29** substantive bug-fix commits, confirming they are the primary risk area.

### 2.4 Open GitHub Issues

**Issue #628** (OPEN, Jun 2025): `BroadcastConsensus` blocks indefinitely when a peer has an abrupt network failure. gRPC `pickerWrapper.pick()` does not time out when a TCP connection is killed without teardown. TPS drops to near zero even though the protocol should tolerate f faulty nodes. Diagnosed; fix identified as a Hyperledger Fabric transport change, not in SmartBFT itself.

---

## Phase 3: Deep Analysis

### 3.1 Heartbeat Monitor (heartbeatmonitor.go)

#### HBM-1: `timedOut` Permanently Suppresses Timeout (HIGH, UNADDRESSED)

```go
// heartbeatmonitor.go:378-390
func (hm *HeartbeatMonitor) followerTick(now time.Time) {
    if hm.timedOut || hm.lastHeartbeat.IsZero() {  // line 379
        hm.lastHeartbeat = now
        return                                        // EARLY RETURN — no further OnHeartbeatTimeout calls
    }
    ...
    if delta >= hm.hbTimeout {
        hm.handler.OnHeartbeatTimeout(hm.view, hm.leaderID)
        hm.timedOut = true                           // line 389 — set once, never reset within view
        return
    }
}
```

`hm.timedOut` is only cleared at `heartbeatmonitor.go:346` inside `handleCommand`, which runs when a `ChangeRole` command arrives. If the first `OnHeartbeatTimeout` complaint does not produce a successful view change (e.g., quorum stalls, view change messages lost), `followerTick` permanently returns early. The follower stops detecting the dead leader. Liveness failure: system can stall indefinitely with a dead leader.

#### HBM-5: Artificial Heartbeat Silent Drop (HIGH, UNADDRESSED)

```go
// heartbeatmonitor.go:152-160
func (hm *HeartbeatMonitor) InjectArtificialHeartbeat(view uint64, target uint64) {
    ...
    select {
    case hm.artificialHeartbeat <- struct{}{}:  // capacity-1 channel
    default:                                     // SILENT DROP
    }
}
```

When the leader is actively proposing, `InjectArtificialHeartbeat` is called per message. Under proposal bursts, the capacity-1 channel fills and subsequent calls are silently dropped. The follower's `hm.lastHeartbeat` is not updated for the dropped heartbeats. If the delta between `now` and `hm.lastHeartbeat` exceeds `hm.hbTimeout`, `OnHeartbeatTimeout` fires against a live, proposing leader. Spurious view change.

#### HBM-4: hbRespCollector Counts Senders, Not Identical Responses (MEDIUM, UNADDRESSED)

```go
// heartbeatmonitor.go:271-284
if hm.view >= hbr.View {
    hm.Logger.Debugf(...)
    return
}
hm.hbRespCollector[sender] = hbr.View
if uint64(len(hm.hbRespCollector)) >= uint64(hm.f)+1 {
    hm.Logger.Warnf("... will try to sync")
    hm.handler.Sync()
    ...
}
```

Comment in code says "f+1 identical heartbeat responses." The check counts `len(map) >= f+1` distinct senders; it does NOT verify that all `f+1` senders report the **same** view number. A heterogeneous set (e.g., 2 senders at view 5, 1 sender at view 7) triggers sync. The leader syncs when it should not have, disrupting in-progress proposals.

#### HBM-3: Stale `hm.view` Causes Spurious Sync (MEDIUM, UNADDRESSED)

```go
// heartbeatmonitor.go:228-231
if hb.View > hm.view {
    hm.Synchronizer.Sync()
    return
}
```

`hm.view` is updated by `handleCommand` (drains `commandChan`). If a `ChangeRole` command is queued but not yet processed when a heartbeat from the new leader arrives (with the new view number), `hb.View > hm.view` fires and `Sync()` is called unnecessarily, aborting a valid in-progress consensus round.

---

### 3.2 ViewChanger (viewchanger.go)

#### VC-1: Deliver Before Outer Signature Verification in `checkLastDecision` (HIGH, UNADDRESSED)

```go
// viewchanger.go:617-665
// This node is one sequence behind, validate the last decision and deliver
_, err := ValidateLastDecision(vd, v.quorum, v.N, v.Verifier)  // validates INNER decision
if err != nil { ... return false, 0 }

v.deliverDecision(proposal, signatures)  // DELIVERS — Checkpoint updated via MutuallyExclusiveDeliver

select { case <-v.stopChan: return false, 0; default: }

if svd.Signer != sender {               // OUTER ENVELOPE checks happen AFTER delivery
    return false, 0
}
if err = v.Verifier.VerifySignature(...); err != nil {
    ...
    return false, 0                     // sequence advanced but ViewData doesn't count toward quorum
}
```

If outer envelope validation fails after delivery:
- `checkLastDecision` returns `false, 0` — the ViewData entry is invalid
- The caller (`processViewDataMsg`) does not increment the quorum count for this entry
- But the Checkpoint was updated, so `extractCurrentSequence()` returns the advanced sequence
- The quorum for completing the view change is now one short
- In a minimal quorum (n=4, f=1, quorum=3): losing one ViewData means only 2 valid entries — view change fails

A Byzantine node can construct a ViewData with a valid `LastDecision` (f+1 honest commit signatures — the decision is legitimate) plus an invalid outer signature. This forces the victim to advance sequence but fail to complete view change.

Same pattern in `validateNewViewMsg` at lines 1067–1082.

#### VC-2: `committedDuringViewChange` Never Reset (MEDIUM, UNADDRESSED)

```go
// viewchanger.go:109, 492-497, 648
committedDuringViewChange *protos.ViewMetadata  // field on ViewChanger, never cleared

// In getInFlight (lines 492-497):
if inFlightMetadata.LatestSequence+1 == lastDecisionMetadata.LatestSequence &&
    v.committedDuringViewChange != nil &&
    v.committedDuringViewChange.LatestSequence == lastDecisionMetadata.LatestSequence {
    return nil  // suppresses in-flight reporting
}
```

This field is set when a decision is committed during a view change (line 648). It is never cleared in `informNewView`, `startViewChange`, or `processViewChangeMsg`. If a node commits during view change N→N+1, then a second view change N+1→N+2 occurs (for unrelated reasons), the stale `committedDuringViewChange` from the first change suppresses in-flight reporting for the second. If the node has a real in-flight proposal for N+2→N+3, it will not report it, and the new leader may not replay it.

#### VC-3: `StartViewChange` Silent Drop on Channel Overflow (HIGH, UNADDRESSED)

```go
// viewchanger.go:356-361
func (v *ViewChanger) StartViewChange(view uint64, stopView bool) {
    select {
    case v.startChangeChan <- &change{view: view, stopView: stopView}:
    default:  // SILENT DROP
    }
}
```

`startChangeChan` has capacity 2 (line 121). Callers: heartbeat monitor, request timeout handler, and incoming view-change message processing. If the HBM fires `OnHeartbeatTimeout`, the request pool fires a second timeout, and a view-change message arrives — all within the same window — the third call is silently dropped. The ViewChanger's run loop never sees all three triggers. Liveness risk: if the two buffered entries are stale (old view) and the one real trigger is dropped, view change doesn't start.

The internal `startViewChange` (lowercase, line 364) has correct idempotence guards (`v.nextView == v.currView+1` at line 369), so even if all three arrive, only the first matters. The real risk is when all queued entries are for an old view (already processed) and the new trigger is dropped.

#### VC-4: WAL Saves `v.currView` Instead of `v.nextView` (LOW, UNCERTAIN IMPACT)

```go
// viewchanger.go:406-419
if !restore {
    msgToSave := &protos.SavedMessage{
        Content: &protos.SavedMessage_ViewChange{
            ViewChange: &protos.ViewChange{
                NextView: v.currView,  // BUG: saves old view, should be v.nextView
            },
        },
    }
    ...
}
v.currView = v.nextView  // line 419 — increment happens AFTER save
```

The WAL record stores `v.currView` (the view being left), not `v.nextView` (= `v.currView + 1`, the target). However, in the restore path (`processViewChangeMsg(restore=true)`), the stored `NextView` field is never read — the restore re-runs the logic using the current `v.currView`. Impact is likely zero, but the data in the WAL is incorrect and misleading for debugging. Code-review-only classification.

---

### 3.3 Controller (controller.go)

#### CTRL-1: Non-Atomic Two-Lock Update of `currViewNumber` + `currDecisionsInView` (MEDIUM, UNADDRESSED)

```go
// controller.go:407-430
func (c *Controller) changeView(newViewNumber uint64, newProposalSequence uint64, newDecisionsInView uint64) {
    c.abortView(newViewNumber)
    c.setCurrentViewNumber(newViewNumber)      // acquires+releases currViewLock
    c.setCurrentDecisionsInView(newDecisionsInView)  // acquires+releases currDecisionsInViewLock
    c.startView(newProposalSequence)           // reads both
}
```

Between `setCurrentViewNumber` and `setCurrentDecisionsInView`, concurrent `ProcessMessages` callers can invoke `c.leaderID()` (controller.go:234), which reads both. The window produces a transient `(newView, oldDecisions)` combination that maps to a potentially different leader identity than either `(oldView, oldDecisions)` or `(newView, newDecisions)`. This can cause a valid proposal from the correct leader to be rejected, or a heartbeat to be injected for the wrong leader, triggering a view change.

---

### 3.4 View (view.go)

#### V-1: Prepare Messages Lack Inner Field Validation (MEDIUM, UNADDRESSED)

```go
// view.go:447-462
func (v *View) processPrepares(proposal types.Proposal, ...) {
    ...
    for {
        vote := <-v.prepares.votes  // dequeued from vote set
        prepare := vote.GetPrepare()
        if prepare.Digest != expectedDigest {
            continue
        }
        // MISSING: check prepare.View == v.Number
        // MISSING: check prepare.Seq == v.ProposalSequence
```

The `voteSet.registerVote` deduplicates by sender but only validates `message.GetPrepare() != nil`. Inner fields `prepare.View` and `prepare.Seq` are never verified in `processPrepares`. A Byzantine node could send a prepare with correct digest but wrong view/seq. The outer `processMsg` sequence check provides partial protection, but votes entering `nextPrepares` (for sequence N+1) bypass the current-sequence guard.

#### V-2: Goroutine Leak in `processCommits` on View Abort (MEDIUM, UNADDRESSED)

```go
// view.go:538-542
go func(vote *protos.Message) {
    signatureCollector.verifyVote(vote)  // may block on signatureCollector.validVotes
}(vote.Message)
```

Goroutines launched in `processCommits` for signature verification have no cancellation mechanism tied to `abortChan`. When a view is aborted, these goroutines complete their verification and attempt to write to `signatureCollector.validVotes`, which is never drained. Under high view-change frequency, goroutines accumulate.

---

### 3.5 State (state.go)

#### ST-1: `recoverPrepared` Panics on App Checkpoint Sequence Lag (MEDIUM, UNADDRESSED)

```go
// state.go:201-205
func recoverPrepared(...) error {
    ...
    if v.ProposalSequence < prePrepareFromWAL.Seq {
        return fmt.Errorf("WAL has entry with sequence %d but proposalSequence is %d", ...)
    }
```

`v.ProposalSequence` here is set from the application checkpoint (`proposalSequence` argument to `NewProposer`). If the application's checkpoint is stale (the app has not yet committed the last block to its checkpoint, but the WAL has recorded the pre-prepare for that block), `v.ProposalSequence < prePrepareFromWAL.Seq` fires and the process panics. This can happen if the process crashes between writing the WAL entry and the application flushing its checkpoint.

---

### 3.6 Batcher (batcher.go)

#### BA-1: `Reset`/`Close`/`NextBatch` Channel Reference Race (MEDIUM, UNADDRESSED)

```go
// batcher.go:66-92
func (b *Batcher) Close() {
    b.closeLock.Lock()
    close(b.closeChan)       // closes current channel
    b.closeLock.Unlock()
}

func (b *Batcher) Reset() {
    b.closeLock.Lock()
    b.closeChan = make(chan struct{})  // replaces channel reference
    b.closeLock.Unlock()
}
```

`NextBatch` reads `b.closeChan` (line 51) without holding `closeLock`. If `Reset` is called while `NextBatch` is blocking on the old channel, `NextBatch` holds the old `closeChan` reference. A subsequent `Close()` closes the new channel — the in-progress `NextBatch` never unblocks. It returns only on timeout or `submittedChan`.

---

### 3.7 False Positives (Explicitly Excluded)

| Finding | Reason Excluded |
|---------|----------------|
| `CheckInFlight` `maxLastDecisionSequence` Byzantine inflation | Byzantine node cannot present `LastDecision.Seq = S` without f+1 honest commit signatures. Any S in a valid ViewData was already committed by at least one honest node. The max is semantically correct. |
| `ViewChanger.getLeader()` uses `decisionsInView=0` | Correct: new view always starts with `decisionsInView=0`. `getLeader()` is called after `v.currView = v.nextView` (line 419), so the computed leader is for the new view starting fresh. |
| `deliverDecision` not calling `Checkpoint.Set` directly | `v.Application` is `MutuallyExclusiveDeliver` (set at `consensus.go:440`). `MutuallyExclusiveDeliver.Deliver()` at `controller.go:974` calls `Checkpoint.Set`. Checkpoint IS updated. |
| `processViewChangeMsg` double `startViewChange` call | On SpeedUp=false path: first call (line 396) fires when quorum-1 votes reached; second call (line 404) is blocked by `!v.SpeedUpViewChange`. The double-call analysis was wrong; `AbortView` is called once. |
| `blacklistSupported` not shared across views | Each new view creates a fresh View object. `blacklistSupported` starts as false and is lazily set. No cross-View interaction because the ViewChanger's `inFlightView` never enters normal proposal flow. |
| `validateNewViewMsg` Sync-on-future-sequence forcing repeated Syncs | Acknowledged TODO at line 1005. Real liveness risk under Byzantine but requires an adversarial leader that includes a ViewData with a far-future sequence. Classification: code-review / acknowledged limitation. Not suitable for MC as-is because the TODO acknowledges re-validation is needed. |
| `processViewChangeMsg` SpeedUp `== f+1` vs `>= f+1` | Safe due to single-threaded run loop: `processViewChangeMsg` is called once per vote, so count increments by 1. The `== f+1` check is evaluated exactly at the threshold. |

---

## Phase 4: Bug Family Synthesis

See `modeling-brief.md` for the full Bug Family analysis. Summary of families and their mapping:

| Family | Files | Historical bugs | Unaddressed findings | TLA+ priority |
|--------|-------|----------------|---------------------|---------------|
| 1: HBM State Isolation | heartbeatmonitor.go | 1 (HBM reset) | HBM-1, HBM-5, HBM-4, HBM-3 | High |
| 2: Deliver-Before-Validate | viewchanger.go | 4 (double delivery — same family) | VC-1 (checkLastDecision), VC-1' (validateNewViewMsg) | High |
| 3: DecisionsInView Consistency | controller.go, viewchanger.go | 2 (DecisionsInView reset, blacklist offset) | CTRL-1 (two-lock non-atomic) | High |
| 4: Sync×ViewChange Delivery | controller.go, viewchanger.go | 4 CRITICAL (fixed) | None unaddressed | Reference |
| 5: In-Flight Lifecycle | viewchanger.go, util.go | 4 (CheckInFlight, fork VC, panic) | VC-2, VC-3 | High |

---

## Appendix: Notable Commit Diffs

### `62e7161` — DecisionsInView Reset (most recent significant bug)

**Before fix** (inside `sync()`):
```go
if latestDecisionSeq > controllerSequence {
    newDecisionsInView = 0   // reset from checkpoint
    // ...
}
// If same height, newDecisionsInView stays 0 (zero-initialized)
changeView(..., newDecisionsInView)  // passes 0 when should pass current value
```

**After fix**: `newDecisionsInView` initialized from `getCurrentDecisionsInView()` before the conditional, decoupled from the sequence advance check.

### `57f434c` — Comprehensive Deliver Fix (464 additions)

Key insight: running view was not stopped before ViewData was sent. A decision in the concurrent running view would be synced; the ViewChanger would not update the checkpoint for old-view sync results; on the second sync, the ViewChanger would redeliver the same sequence. Fix: abort running view before sending ViewData; update checkpoint on all old-view sync paths.

### `eb005ee` — Decide + Abort Deadlock

Confirmed with production goroutine stack trace showing a View goroutine blocked for 69 minutes. `decisionChan` was unbuffered; `Decide()` sent to it but the Controller's run loop was stuck in `Abort.wg.Wait()` waiting for the View goroutine to finish — which couldn't finish because it was blocked sending to `decisionChan`.
