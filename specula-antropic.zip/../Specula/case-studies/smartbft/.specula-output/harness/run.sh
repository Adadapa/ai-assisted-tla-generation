#!/usr/bin/env bash
set -euo pipefail

REPO=/Users/tess/dev/Specula/case-studies/smartbft/SmartBFT
OUTPUT_DIR=/Users/tess/dev/Specula/case-studies/smartbft/.specula-output
TRACES_DIR="$OUTPUT_DIR/traces"

echo "[run] Creating traces directory..."
mkdir -p "$TRACES_DIR"

echo "[run] Applying harness..."
bash "$OUTPUT_DIR/harness/apply.sh"

echo "[run] Building..."
cd "$REPO" && go build ./...

echo "[run] Running trace tests (one per invocation to avoid global TLATrace races)..."

echo "[run]   TestTLATraceNormal..."
cd "$REPO" && go test -v -count=1 -run 'TestTLATraceNormal' \
    -timeout 60s ./test/ 2>&1 || true

echo "[run]   TestTLATraceViewChange..."
cd "$REPO" && go test -v -count=1 -run 'TestTLATraceViewChange' \
    -timeout 60s ./test/ 2>&1 || true

echo "[run]   TestTLATraceHBTimeout..."
cd "$REPO" && go test -v -count=1 -run 'TestTLATraceHBTimeout' \
    -timeout 60s ./test/ 2>&1 || true

echo "[run]   TestTLATraceVCDeliver..."
cd "$REPO" && go test -v -count=1 -run 'TestTLATraceVCDeliver' \
    -timeout 120s ./test/ 2>&1 || true

echo "[run] Trace file line counts:"
wc -l "$TRACES_DIR"/*.ndjson 2>/dev/null || echo "no traces"

echo "[run] Done."
