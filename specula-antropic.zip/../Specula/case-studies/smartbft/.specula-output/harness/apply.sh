#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
REPO=/Users/tess/dev/Specula/case-studies/smartbft/SmartBFT

echo "[apply] Resetting repo to clean state..."
cd "$REPO" && git checkout -- .

echo "[apply] Copying tla_trace.go..."
cp "$SCRIPT_DIR/src/tla_trace.go" "$REPO/internal/bft/tla_trace.go"

echo "[apply] Applying instrumentation patch..."
cd "$REPO" && git apply "$SCRIPT_DIR/patches/instrumentation.patch"

echo "[apply] Copying tla_trace_scenarios_test.go..."
cp "$SCRIPT_DIR/src/tla_trace_scenarios_test.go" "$REPO/test/tla_trace_scenarios_test.go"

echo "[apply] Done."
