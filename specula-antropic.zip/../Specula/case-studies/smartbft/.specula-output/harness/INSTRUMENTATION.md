# SmartBFT Trace Instrumentation Guide

## Instrumented Events

| Event | Source File | Trigger Point |
|---|---|---|
| `propose` | `internal/bft/view.go` | After `v.HandleMessage(v.LeaderID, msg)` in `Propose()` — leader only |
| `pre_prepare` | `internal/bft/view.go` | After `v.inFlightProposal = &proposal` in `processProposal()` — all nodes |
| `decide` | `internal/bft/controller.go` | After `c.incrementCurrentDecisionsInView()` in `decide()` — all nodes |
| `update_view` | `internal/bft/controller.go` | After `c.setCurrentViewNumber()` in `changeView()` |
| `update_decisions` | `internal/bft/controller.go` | After `c.setCurrentDecisionsInView()` in `changeView()` |
| `hb_timeout` | `internal/bft/heartbeatmonitor.go` | Before `hm.handler.OnHeartbeatTimeout()` in `followerTick()` |
| `change_role` | `internal/bft/heartbeatmonitor.go` | After all field updates in `handleCommand()` |
| `view_change_start` | `internal/bft/viewchanger.go` | After the `select { case v.startChangeChan <- ...: ...; default: }` in `StartViewChange()` |
| `vc_deliver` | `internal/bft/viewchanger.go` | After `v.deliverDecision()` in `checkLastDecision()` (seq+1 branch) |
| `vc_validate` | `internal/bft/viewchanger.go` | After `v.Verifier.VerifySignature()` in `checkLastDecision()` (seq+1 branch, right after vc_deliver) |
| `vc_same_seq` | `internal/bft/viewchanger.go` | After `v.Verifier.VerifySignature()` in `checkLastDecision()` (same-seq branch) |
| `enter_new_view` | `internal/bft/viewchanger.go` | After `v.Controller.ViewChanged()` in `processNewViewMsg()` |

## File Locations After apply.sh

- `internal/bft/tla_trace.go` — trace emitter (mutex-protected global writer)
- `internal/bft/controller.go` — `propose`, `decide`, `update_view`, `update_decisions` emits
- `internal/bft/view.go` — `pre_prepare` emit
- `internal/bft/viewchanger.go` — `view_change_start`, `vc_deliver`, `vc_validate`, `vc_same_seq`, `enter_new_view` emits
- `internal/bft/heartbeatmonitor.go` — `hb_timeout`, `change_role` emits + `SelfID` field
- `pkg/consensus/consensus.go` — sets `leaderMonitor.SelfID` so HBM events have correct node ID
- `test/tla_trace_scenarios_test.go` — 4 test scenarios

## How to Add a Field to an Existing Event

1. Find the `TLATrace.Emit(map[string]interface{}{...})` block for the event in the file listed above.
2. Add the new key-value pair to the map.
3. Run `bash /Users/tess/dev/Specula/case-studies/smartbft/.specula-output/harness/run.sh`.

## How to Add a New Event

1. Find an existing `TLATrace.Emit(...)` block near the desired location.
2. Copy the block, insert it at the new location.
3. Change the `"event"` value to the new event name.
4. Add/remove fields as needed.
5. Add a corresponding `TraceXxx` action wrapper to `spec/Trace.tla` and add it to `TraceNext`.
6. Run `bash /Users/tess/dev/Specula/case-studies/smartbft/.specula-output/harness/run.sh`.

## How to Move a Capture Point

- Before → after: move the `TLATrace.Emit(...)` block past the desired statement.
- The most common adjustment is moving `decide` emit relative to `incrementCurrentDecisionsInView()` — it must be AFTER the increment so `getCurrentDecisionsInView()` returns the post-state value.

## How to Rebuild and Re-run

```bash
bash /Users/tess/dev/Specula/case-studies/smartbft/.specula-output/harness/run.sh
```

This resets the repo to clean state, re-applies the patch, rebuilds, runs all 4 tests in separate invocations, and reports trace line counts.

## State Capture Levels

All events use **Full** capture (all fields available at trigger point). The only exception:

- `hb_timeout` and `change_role` run inside the HBM goroutine. They only have access to HBM state (`hbm_*` fields). Controller state (`ctrl_view`, `ctrl_decisions`) is not captured because the HBM goroutine does not hold the controller lock. This is documented in `instrumentation-spec.md` Section 3.1.

## Test Scenarios and What They Cover

| Test | Trace File | Events Generated |
|------|-----------|------------------|
| `TestTLATraceNormal` | `trace_normal.ndjson` | `change_role`, `propose`, `pre_prepare`, `decide` |
| `TestTLATraceViewChange` | `trace_view_change.ndjson` | All normal + `hb_timeout`, `view_change_start`, `vc_same_seq`, `enter_new_view`, `update_view`, `update_decisions` |
| `TestTLATraceHBTimeout` | `trace_hb_timeout.ndjson` | `hb_timeout`, `view_change_start`, `enter_new_view`, `update_view`, `update_decisions`, `change_role` (multiple view changes) |
| `TestTLATraceVCDeliver` | `trace_vc_deliver.ndjson` | All view-change events + `vc_deliver`, `vc_validate` (Family 2 deliver-before-validate path) |

## Note on vc_deliver / vc_validate

These events fire only when the new leader is one sequence behind a VIEW_DATA sender. To reproduce: run `TestTLATraceVCDeliver`, which:

1. Disconnects node 2 (view-1 leader) before seq 1 is committed.
2. Lets nodes 1, 3, 4 commit seq 1 with quorum (3 of 4).
3. Disconnects node 1, reconnects node 2, triggers view change.
4. Node 2 (seq=0) receives VIEW_DATA from node 3 (seq=1) → `vc_deliver` + `vc_validate`.

## Note on hb_timeout

The `hb_timeout` event fires only when `LeaderHeartbeatTimeout` (1 minute in test config) elapses without a heartbeat from the leader. The tests use a manual clock channel (`n.heartbeatTime`) with time jumps of 90 seconds to trigger this instantly. Do NOT call `n.Consensus.Stop()` before `n.Setup()` in test setup — the Consensus was created by `newNode` but not yet started, so its internal ViewChanger is nil and Stop() would panic.
