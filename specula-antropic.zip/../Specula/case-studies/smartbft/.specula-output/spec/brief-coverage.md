# Brief Coverage Self-Audit

Mapping of brief §2 (Bug Families), §5 (Proposed Invariants), and §6.1 (Model-Checkable Findings)
to spec actions and hunt configs. Filled by reading actual cfg files, not from memory.

---

## §2 Bug Families → Hunt Configs

| Family | Mechanism | Hunt Config | Notes |
|--------|-----------|-------------|-------|
| Family 1 (HBM State Isolation) | `timedOut` suppression; artificial HB drop | `MC_hunt_family1.cfg` | Targets `NoFalseTimeout`. Both sub-bugs (MC-1 and MC-2) covered: `HBFollowerTick` models timedOut gate; `InjectArtificialHeartbeat` models capacity-1 drop. |
| Family 2 (Deliver-Before-Validate) | `deliverDecision` at line 640 before `VerifySignature` at line 660 | `MC_hunt_family2.cfg` | Targets `DeliverImpliesViewEntered`. `ByzantineViewData` injects `outer_valid=FALSE`; `ProcessViewDataDeliver`/`ProcessViewDataValidate` are split actions modeling the two-step. Byzantine={4} with MaxByzMsgs=1. |
| Family 3 (DecisionsInView/Leader Identity) | Non-atomic two-lock update in `changeView` | `MC_hunt_family3.cfg` | Targets `LeaderIdentityConsistency`. `ChangeViewUpdateView` and `ChangeViewUpdateDecisions` are split actions; `ctrl_updating` marks the window. `ReadLeaderID` fires during window. `LeaderRotation=TRUE` to maximize impact of (view,decisions) divergence. |
| Family 4 (Sync–ViewChange Delivery) | Double delivery via concurrent sync+VC | *Not modeled* | Brief §3.2 explicitly excludes: "Fixed by MutuallyExclusiveDeliver + syncLock; reproducing this yields no new information." |
| Family 5 (In-Flight Proposal Lifecycle) | `committedDuringViewChange` never reset; `StartViewChange` drop | `MC_hunt_family5.cfg` | Targets `InFlightReplay`. `committed_during_vc` variable models stale state; `GetInFlightSeq` operator encodes suppression logic (viewchanger.go:492-497). `MaybeStartViewChange` non-deterministically drops. Requires MaxViewChanges≥4 for two consecutive VCs. |

---

## §5 Proposed Invariants → Spec Definition and Hunt Config Coverage

| Invariant | Type | Defined In | Wired In MC.tla | Enabled In ≥1 Hunt Cfg |
|-----------|------|-----------|-----------------|------------------------|
| Agreement | Safety | `base.tla` | `MCTypeOK` block; `Agreement` in `INVARIANTS` | `MC.cfg` + all hunt cfgs |
| ViewChangeSafety | Safety | `base.tla` | `ViewChangeSafety` in `INVARIANTS` | `MC.cfg` |
| NoFalseTimeout | Safety | `base.tla` | Commented out in `MC.cfg` (extension) | `MC_hunt_family1.cfg` ✓ |
| HeartbeatTimedOutImpliesComplain | Liveness | *not modeled as invariant* | — | Liveness form; not expressible as TLC safety invariant. Checked implicitly: if `hbm_timed_out` suppression fires, `NoFalseTimeout` would be violated. MC-1 scenario. |
| LeaderIdentityConsistency | Safety | `base.tla` | Commented out in `MC.cfg` | `MC_hunt_family3.cfg` ✓ |
| DeliverImpliesViewEntered | Safety | `base.tla` | Commented out in `MC.cfg` | `MC_hunt_family2.cfg` ✓ |
| InFlightReplay | Safety | `base.tla` | Commented out in `MC.cfg` | `MC_hunt_family5.cfg` ✓ |
| StartViewChangeLiveness | Liveness | *not modeled as invariant* | — | Liveness form (temporal property). MC-6 scenario covered by `vc_start_dropped` variable; `InFlightReplay` catches the downstream safety consequence. |

**Note on liveness invariants**: `HeartbeatTimedOutImpliesComplain` and `StartViewChangeLiveness` are eventuality properties. TLC can check these as temporal properties (`PROPERTIES <>P`) but they require fairness assumptions and are expensive. The safety consequences of both bugs are captured by `NoFalseTimeout` and `InFlightReplay` respectively, which suffice for bug hunting. If liveness checking is needed, add `<>[]NoFalseTimeout` as a temporal property with weak fairness on tick actions.

---

## §6.1 Model-Checkable Findings → Hunt Config Reachability

| Finding | Expected Invariant | Hunt Config | Trigger Reachable? |
|---------|--------------------|-------------|-------------------|
| MC-1: `hbm_timed_out` suppression — can stall permanently | `HeartbeatTimedOutImpliesComplain` (liveness) / `NoFalseTimeout` | `MC_hunt_family1.cfg` | Yes. `HBFollowerTick` fires only when `~hbm_timed_out`. If first complaint doesn't produce view change (MaxViewChanges=2), and no `ProcessChangeRole` arrives to reset `hbm_timed_out`, node is stuck. |
| MC-2: Artificial HB drop causes spurious timeout against live leader | `NoFalseTimeout` | `MC_hunt_family1.cfg` | Yes. `InjectArtificialHeartbeat` with `hbm_artif_pending=TRUE` drops; `HBFollowerTick` sees no HEARTBEAT in msgs; fires even though leader is in NORMAL phase. |
| MC-3: Non-atomic two-lock update → wrong leader identity | `LeaderIdentityConsistency` | `MC_hunt_family3.cfg` | Yes. `ChangeViewUpdateView` sets `ctrl_view`; `ReadLeaderID` fires before `ChangeViewUpdateDecisions`; nodes at old decisions see different leader than those at new view. `LeaderRotation=TRUE` maximizes exposure. |
| MC-4: Byzantine ViewData with invalid outer sig → seq advances without quorum | `DeliverImpliesViewEntered` | `MC_hunt_family2.cfg` | Yes. `ByzantineViewData` sends `outer_valid=FALSE` to new leader; `ProcessViewDataDeliver` advances log; `ProcessViewDataValidate` fails and does not add sender to `vc_quorum`; invariant checks quorum ≥ Quorum while `vc_delivered_seq /= NULL`. |
| MC-5: Stale `committedDuringViewChange` suppresses in-flight on 2nd VC | `InFlightReplay` | `MC_hunt_family5.cfg` | Yes. First VC sets `committed_during_vc`; second VC: `GetInFlightSeq` sees stale value → returns NULL → in-flight not reported; `BuildNewView` excludes it; `InFlightReplay` checks `GetInFlightSeq(s) /= NULL` when `in_flight[s] /= NULL`. Requires MaxViewChanges=4. |
| MC-6: `StartViewChange` drop under concurrent triggers | `StartViewChangeLiveness` (liveness) / `InFlightReplay` (safety consequence) | `MC_hunt_family5.cfg` | Partially. `MaybeStartViewChange` non-deterministically sets `vc_start_dropped=TRUE`. Safety consequence (node never completes view change → in-flight lost) captured by `InFlightReplay`. True liveness check (eventually view change fires) requires temporal property — not in safety-only hunt cfg. |

---

## Config Notes

- **Symmetry reduction removed**: TLC's `SYMMETRY Permutations(Server)` requires model values as the server domain. The configs use integer server IDs (`Server = {1,2,3,4}`) for `MCNodesList` sequence indexing. To restore symmetry, replace integers with model values `{s1,s2,s3,s4}` and update `MCNodesList` accordingly.
- **NodesList**: Sequence literals (`<<1,2,3,4>>`) are not valid in TLC cfg files. All configs use `NodesList <- MCNodesList` where `MCNodesList == <<1,2,3,4>>` is defined in `base.tla`.

## Gaps and Explicit Scope Decisions

1. **`hbRespCollector` heterogeneous views (TV-1 from §6.2)**: Not modeled. Brief §3.2 notes this is test-verifiable; modeling it in TLA+ requires tracking per-sender view in heartbeat response, which adds variable complexity without additional safety check value beyond TV-1's unit test.

2. **`StartViewChangeLiveness` as temporal property**: Excluded from hunt cfgs because TLC temporal property checking requires fairness assumptions over an unconstrained action space. The safety downstream consequence (`InFlightReplay`) is checked instead. A dedicated simulation run with `MaxViewChanges=8` can explore whether `vc_start_dropped` ever leaves `phase[s] = "VC_STARTED"` permanently.

3. **Family 4 (historical)**: Explicitly excluded per brief §3.2. MutuallyExclusiveDeliver + syncLock already fixed this; no hunt cfg generated.

4. **`committed_during_vc` reset semantics**: The variable is reset on `Crash` (volatile), consistent with implementation. Between view changes without crash, it is never reset — the bug. `GetInFlightSeq` encodes the exact suppression logic from viewchanger.go:492-497.

5. **All 6 MC findings have a targeting hunt config**: MC-1→family1, MC-2→family1, MC-3→family3, MC-4→family2, MC-5→family5, MC-6→family5. No finding is orphaned.
