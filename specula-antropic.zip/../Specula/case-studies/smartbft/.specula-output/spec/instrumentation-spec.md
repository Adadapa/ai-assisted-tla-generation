# Instrumentation Spec — SmartBFT

Mapping from TLA+ spec actions to source code locations for trace harness generation.
One entry per spec action; all code locations are in `internal/bft/`.

---

## Section 1: Trace Event Schema

### Event envelope (every event)

```json
{
  "event":  "<string>",
  "node":   <int>,
  "ts_ns":  <int64>
}
```

### State snapshot fields (captured at every event)

| Trace field | Go source | TLA+ variable |
|-------------|-----------|---------------|
| `ctrl_view` | `c.getCurrentViewNumber()` | `ctrl_view[node]` |
| `ctrl_decisions` | `c.getCurrentDecisionsInView()` | `ctrl_decisions[node]` |
| `phase` | derived: normal/vc/new_view state | `phase[node]` |
| `log_len` | `c.latestSeq()` | `Len(log[node])` |

### HBM-specific snapshot fields (events from heartbeatmonitor.go)

| Trace field | Go source | TLA+ variable |
|-------------|-----------|---------------|
| `hbm_view` | `hm.view` | `hbm_view[node]` |
| `hbm_timed_out` | `hm.timedOut` | `hbm_timed_out[node]` |
| `hbm_role` | `hm.follower` (bool) | `hbm_role[node]` |

---

## Section 2: Action-to-Code Mapping

### 1. `Propose`

| Field | Value |
|-------|-------|
| **Spec action** | `Propose(s)` |
| **Code location** | `controller.go:494` — `c.currView.Propose(proposal)` |
| **Trigger point** | After `c.currView.Propose(proposal)` returns |
| **Event name** | `"propose"` |
| **Fields** | `node`, `view` (= `c.getCurrentViewNumber()`), `seq` (= `c.latestSeq()+1`) |
| **Notes** | Only leader emits this. Capture before the Propose call sends PREPREPARE. |

---

### 2. `HandlePrePrepare`

| Field | Value |
|-------|-------|
| **Spec action** | `HandlePrePrepare(s)` |
| **Code location** | `view.go` — pre-prepare handler, after `inFlight` is stored |
| **Trigger point** | After in-flight proposal is set (before PREPARE broadcast) |
| **Event name** | `"pre_prepare"` |
| **Fields** | `node`, `view`, `seq`, `sender` |
| **Notes** | Followers only. `seq` = `inFlight.LatestSequence`. |

---

### 3. `Decide`

| Field | Value |
|-------|-------|
| **Spec action** | `Decide(s, from)` |
| **Code location** | `controller.go:539` — `c.Deliver.Deliver(d.proposal, d.signatures)` |
| **Trigger point** | After `Deliver` returns (post-delivery state) |
| **Event name** | `"decide"` |
| **Fields** | `node`, `seq` (= `c.latestSeq()+1` at time of delivery), `view` (= `c.getCurrentViewNumber()`), `decisions_in_view` (= `c.getCurrentDecisionsInView()+1`), `commit_sender` (any sender from commit_votes — for spec from-parameter) |
| **Notes** | `decisions_in_view` captured AFTER `c.incrementCurrentDecisionsInView()` at controller.go:550. |

---

### 4. `HBFollowerTick` / `OnHeartbeatTimeout`

| Field | Value |
|-------|-------|
| **Spec action** | `HBFollowerTick(s)` |
| **Code location** | `heartbeatmonitor.go:388` — `hm.handler.OnHeartbeatTimeout(hm.view, hm.leaderID)` |
| **Trigger point** | Before `OnHeartbeatTimeout` call (pre-state); timedOut not yet set |
| **Event name** | `"hb_timeout"` |
| **Fields** | `node`, `view` (= `hm.view`), `leader` (= `hm.leaderID`), `hbm_timed_out_before` (= `hm.timedOut` before this tick — should be false) |
| **Notes** | This fires inside the HBM goroutine. Emit before `hm.timedOut = true` (line 389). |

---

### 5. `ProcessChangeRole`

| Field | Value |
|-------|-------|
| **Spec action** | `ProcessChangeRole(s, newView, newLeader)` |
| **Code location** | `heartbeatmonitor.go:342` — inside `handleCommand`, after all state fields are updated |
| **Trigger point** | After `hm.timedOut = false` (line 346) and all field updates |
| **Event name** | `"change_role"` |
| **Fields** | `node`, `view` (= `cmd.view`), `leader` (= `cmd.leaderID`), `role` (`"leader"` if `!cmd.follower`, else `"follower"`) |
| **Notes** | This runs inside the HBM goroutine (select case on `commandChan`). Emit at end of `handleCommand`. |

---

### 6. `MaybeStartViewChange` (and `StartViewChange` drop detection)

| Field | Value |
|-------|-------|
| **Spec action** | `MaybeStartViewChange(s)` |
| **Code location** | `viewchanger.go:357-360` — `select { case v.startChangeChan <- ...: ...; default: }` |
| **Trigger point** | Inside the `select` statement, after the branch is taken |
| **Event name** | `"view_change_start"` |
| **Fields** | `node`, `next_view` (= `v.currView+1`), `dropped` (`true` if `default` branch taken, `false` if channel branch taken) |
| **Notes** | Wrap the `select` in `StartViewChange` at viewchanger.go:356-361. Use a local variable to track which branch fired. |

---

### 7. `ProcessViewDataDeliver` (step 1)

| Field | Value |
|-------|-------|
| **Spec action** | `ProcessViewDataDeliver(s, from)` |
| **Code location** | `viewchanger.go:640` — `v.deliverDecision(proposal, signatures)` |
| **Trigger point** | After `v.deliverDecision` returns (delivery done, seq advanced) |
| **Event name** | `"vc_deliver"` |
| **Fields** | `node`, `from` (= `sender` argument of `checkLastDecision`), `seq` (= `lastDecisionMD.LatestSequence`), `view` (= `v.currView`) |
| **Notes** | Only fires in the `lastDecisionMD.LatestSequence == mySequence+1` branch (viewchanger.go:616-666). |

---

### 8. `ProcessViewDataValidate` (step 2)

| Field | Value |
|-------|-------|
| **Spec action** | `ProcessViewDataValidate(s, from)` |
| **Code location** | `viewchanger.go:660` — after `v.Verifier.VerifySignature(...)` returns |
| **Trigger point** | After the VerifySignature call at line 660 |
| **Event name** | `"vc_validate"` |
| **Fields** | `node`, `from` (= sender), `view`, `valid` (`true` if VerifySignature returned nil, `false` otherwise) |
| **Notes** | Emit regardless of signature validity — both outcomes are important for tracing the Family 2 bug. Only emit when `ProcessViewDataDeliver` was emitted for the same sender (i.e., only in the seq+1 branch). |

---

### 9. `EnterNewView`

| Field | Value |
|-------|-------|
| **Spec action** | `EnterNewView(s)` |
| **Code location** | `viewchanger.go` — after `processNewViewMsg` completes view entry and calls `v.Controller.ViewChanged` |
| **Trigger point** | After `ViewChanged` is called (new view accepted) |
| **Event name** | `"enter_new_view"` |
| **Fields** | `node`, `view` (= new vc_view), `proposal_seq` (= new proposal sequence) |
| **Notes** | Also covers the new leader path (after `BuildNewView` → self `processMsg`). |

---

### 10. `ChangeViewUpdateView` (non-atomic step 1)

| Field | Value |
|-------|-------|
| **Spec action** | `ChangeViewUpdateView(s)` |
| **Code location** | `controller.go:427` — `c.setCurrentViewNumber(newViewNumber)` |
| **Trigger point** | After `setCurrentViewNumber` returns (before `setCurrentDecisionsInView`) |
| **Event name** | `"update_view"` |
| **Fields** | `node`, `view` (= newViewNumber) |
| **Notes** | Critical timing: emit BETWEEN `setCurrentViewNumber` and `setCurrentDecisionsInView` at controller.go:427-428. |

---

### 11. `ChangeViewUpdateDecisions` (non-atomic step 2)

| Field | Value |
|-------|-------|
| **Spec action** | `ChangeViewUpdateDecisions(s, d)` |
| **Code location** | `controller.go:428` — `c.setCurrentDecisionsInView(newDecisionsInView)` |
| **Trigger point** | After `setCurrentDecisionsInView` returns |
| **Event name** | `"update_decisions"` |
| **Fields** | `node`, `decisions` (= newDecisionsInView) |
| **Notes** | Emit AFTER `setCurrentDecisionsInView`. The window between `update_view` and `update_decisions` is where Family 3 bug manifests. |

---

### 12. `ProcessViewDataSameSeq`

| Field | Value |
|-------|-------|
| **Spec action** | `ProcessViewDataSameSeq(s, from)` |
| **Code location** | `viewchanger.go:592-610` — same-seq branch in `checkLastDecision` |
| **Trigger point** | After `VerifySignature` at line 598 returns |
| **Event name** | `"vc_same_seq"` |
| **Fields** | `node`, `from`, `seq`, `view`, `valid` |
| **Notes** | Only emits in the `lastDecisionMD.LatestSequence == mySequence` branch, no delivery happens. |

---

## Section 3: Special Considerations

### 3.1 Three independent goroutines

Events from Controller, ViewChanger, and HeartbeatMonitor interleave freely. The trace is a single linearized sequence; the harness must include a `ts_ns` timestamp on every event so trace validation can reconstruct ordering. For borderline concurrent events (e.g., `update_view` vs `hb_timeout`), the real execution timestamp disambiguates.

### 3.2 `committedDuringViewChange` field access

`v.committedDuringViewChange` is a private field on `ViewChanger`. To trace its value, add a shadow getter or read it directly inside the instrumentation point at viewchanger.go:648. The stale-value bug (Family 5) requires capturing this field at the start of `getInFlight` calls to observe when the stale value suppresses the in-flight report.

### 3.3 Bootstrap / genesis state

At startup, `log_len = 0`, all views and decisions = 0. `TraceInit` in Trace.tla matches this. The genesis branch (`LastDecision.Metadata == nil`) in `checkLastDecision`/`validateNewViewMsg` does not emit `vc_deliver` events; no delivery happens at genesis.

### 3.4 `outer_valid` flag modeling

In real execution, `v.Verifier.VerifySignature` returns `nil` for valid signatures. The `valid` field in `"vc_validate"` events must capture the exact return value of `VerifySignature` (nil → `true`, error → `false`). The `outer_valid` field in `VIEW_DATA` messages in the spec is an abstraction; the trace captures the concrete result.

### 3.5 Non-atomic update window observable in traces

The `"update_view"` and `"update_decisions"` events will always appear as consecutive events in correct execution (between them, no other Controller event is expected). If a trace shows other events between these two, it indicates concurrent processing that entered the non-atomic window — exactly what Family 3 checks for. The harness should NOT suppress intervening events to preserve this interleaving evidence.
