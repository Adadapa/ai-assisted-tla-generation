---- MODULE Trace_TTrace_1781298753 ----
EXTENDS Trace, Sequences, TLCExt, Toolbox, Naturals, TLC

_expression ==
    LET Trace_TEExpression == INSTANCE Trace_TEExpression
    IN Trace_TEExpression!expression
----

_trace ==
    LET Trace_TETrace == INSTANCE Trace_TETrace
    IN Trace_TETrace!trace
----

_inv ==
    ~(
        TLCGet("level") = Len(_TETrace)
        /\
        phase = (<<"NORMAL", "NORMAL", "VC_STARTED", "NORMAL">>)
        /\
        vc_delivered_seq = (<<0, 0, 0, 0>>)
        /\
        msgs = ({[type |-> "VIEW_CHANGE", sender |-> 3, next_view |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]})
        /\
        ctrl_updating = (<<FALSE, FALSE, FALSE, FALSE>>)
        /\
        commit_votes = (<<(0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>)
        /\
        hbm_chg_pend = (<<FALSE, FALSE, FALSE, FALSE>>)
        /\
        vc_start_dropped = (<<FALSE, FALSE, FALSE, FALSE>>)
        /\
        log = (<<<<1>>, <<>>, <<1>>, <<1>>>>)
        /\
        blacklist = (<<{}, {}, {}, {}>>)
        /\
        ctrl_decisions = (<<1, 0, 1, 1>>)
        /\
        l = (13)
        /\
        hbm_role = (<<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>)
        /\
        prepare_votes = (<<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>)
        /\
        hbm_timed_out = (<<FALSE, FALSE, TRUE, FALSE>>)
        /\
        hbm_artif_pending = (<<FALSE, FALSE, FALSE, FALSE>>)
        /\
        vc_view = (<<0, 0, 0, 0>>)
        /\
        vc_quorum = (<<{}, {}, {}, {}>>)
        /\
        ctrl_view_pending = (<<0, 0, 0, 0>>)
        /\
        ctrl_view = (<<0, 0, 0, 0>>)
        /\
        committed_during_vc = (<<0, 0, 0, 0>>)
        /\
        hbm_view = (<<0, 0, 0, 0>>)
        /\
        in_flight = (<<0, 0, 0, 0>>)
    )
----

_init ==
    /\ phase = _TETrace[1].phase
    /\ hbm_view = _TETrace[1].hbm_view
    /\ commit_votes = _TETrace[1].commit_votes
    /\ blacklist = _TETrace[1].blacklist
    /\ log = _TETrace[1].log
    /\ committed_during_vc = _TETrace[1].committed_during_vc
    /\ l = _TETrace[1].l
    /\ vc_view = _TETrace[1].vc_view
    /\ prepare_votes = _TETrace[1].prepare_votes
    /\ vc_delivered_seq = _TETrace[1].vc_delivered_seq
    /\ in_flight = _TETrace[1].in_flight
    /\ hbm_role = _TETrace[1].hbm_role
    /\ vc_quorum = _TETrace[1].vc_quorum
    /\ hbm_timed_out = _TETrace[1].hbm_timed_out
    /\ hbm_chg_pend = _TETrace[1].hbm_chg_pend
    /\ vc_start_dropped = _TETrace[1].vc_start_dropped
    /\ msgs = _TETrace[1].msgs
    /\ ctrl_decisions = _TETrace[1].ctrl_decisions
    /\ ctrl_updating = _TETrace[1].ctrl_updating
    /\ ctrl_view = _TETrace[1].ctrl_view
    /\ hbm_artif_pending = _TETrace[1].hbm_artif_pending
    /\ ctrl_view_pending = _TETrace[1].ctrl_view_pending
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ phase  = _TETrace[i].phase
        /\ phase' = _TETrace[j].phase
        /\ hbm_view  = _TETrace[i].hbm_view
        /\ hbm_view' = _TETrace[j].hbm_view
        /\ commit_votes  = _TETrace[i].commit_votes
        /\ commit_votes' = _TETrace[j].commit_votes
        /\ blacklist  = _TETrace[i].blacklist
        /\ blacklist' = _TETrace[j].blacklist
        /\ log  = _TETrace[i].log
        /\ log' = _TETrace[j].log
        /\ committed_during_vc  = _TETrace[i].committed_during_vc
        /\ committed_during_vc' = _TETrace[j].committed_during_vc
        /\ l  = _TETrace[i].l
        /\ l' = _TETrace[j].l
        /\ vc_view  = _TETrace[i].vc_view
        /\ vc_view' = _TETrace[j].vc_view
        /\ prepare_votes  = _TETrace[i].prepare_votes
        /\ prepare_votes' = _TETrace[j].prepare_votes
        /\ vc_delivered_seq  = _TETrace[i].vc_delivered_seq
        /\ vc_delivered_seq' = _TETrace[j].vc_delivered_seq
        /\ in_flight  = _TETrace[i].in_flight
        /\ in_flight' = _TETrace[j].in_flight
        /\ hbm_role  = _TETrace[i].hbm_role
        /\ hbm_role' = _TETrace[j].hbm_role
        /\ vc_quorum  = _TETrace[i].vc_quorum
        /\ vc_quorum' = _TETrace[j].vc_quorum
        /\ hbm_timed_out  = _TETrace[i].hbm_timed_out
        /\ hbm_timed_out' = _TETrace[j].hbm_timed_out
        /\ hbm_chg_pend  = _TETrace[i].hbm_chg_pend
        /\ hbm_chg_pend' = _TETrace[j].hbm_chg_pend
        /\ vc_start_dropped  = _TETrace[i].vc_start_dropped
        /\ vc_start_dropped' = _TETrace[j].vc_start_dropped
        /\ msgs  = _TETrace[i].msgs
        /\ msgs' = _TETrace[j].msgs
        /\ ctrl_decisions  = _TETrace[i].ctrl_decisions
        /\ ctrl_decisions' = _TETrace[j].ctrl_decisions
        /\ ctrl_updating  = _TETrace[i].ctrl_updating
        /\ ctrl_updating' = _TETrace[j].ctrl_updating
        /\ ctrl_view  = _TETrace[i].ctrl_view
        /\ ctrl_view' = _TETrace[j].ctrl_view
        /\ hbm_artif_pending  = _TETrace[i].hbm_artif_pending
        /\ hbm_artif_pending' = _TETrace[j].hbm_artif_pending
        /\ ctrl_view_pending  = _TETrace[i].ctrl_view_pending
        /\ ctrl_view_pending' = _TETrace[j].ctrl_view_pending

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("Trace_TTrace_1781298753.json", _TETrace)

=============================================================================

 Note that you can extract this module `Trace_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `Trace_TEExpression.tla` file takes precedence 
  over the module `Trace_TEExpression` below).

---- MODULE Trace_TEExpression ----
EXTENDS Trace, Sequences, TLCExt, Toolbox, Naturals, TLC

expression == 
    [
        \* To hide variables of the `Trace` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        phase |-> phase
        ,hbm_view |-> hbm_view
        ,commit_votes |-> commit_votes
        ,blacklist |-> blacklist
        ,log |-> log
        ,committed_during_vc |-> committed_during_vc
        ,l |-> l
        ,vc_view |-> vc_view
        ,prepare_votes |-> prepare_votes
        ,vc_delivered_seq |-> vc_delivered_seq
        ,in_flight |-> in_flight
        ,hbm_role |-> hbm_role
        ,vc_quorum |-> vc_quorum
        ,hbm_timed_out |-> hbm_timed_out
        ,hbm_chg_pend |-> hbm_chg_pend
        ,vc_start_dropped |-> vc_start_dropped
        ,msgs |-> msgs
        ,ctrl_decisions |-> ctrl_decisions
        ,ctrl_updating |-> ctrl_updating
        ,ctrl_view |-> ctrl_view
        ,hbm_artif_pending |-> hbm_artif_pending
        ,ctrl_view_pending |-> ctrl_view_pending
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_phaseUnchanged |-> phase = phase'
        
        \* Format the `phase` variable as Json value.
        \* ,_phaseJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(phase)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_phaseModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].phase # _TETrace[s-1].phase
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE Trace_TETrace ----
\*EXTENDS Trace, IOUtils, TLC
\*
\*trace == IODeserialize("Trace_TTrace_1781298753.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE Trace_TETrace ----
EXTENDS Trace, TLC

trace == 
    <<
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 1,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<TRUE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 1,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 2,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, TRUE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 2,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 3,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, TRUE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 3,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 4,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, TRUE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 4,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 5,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 6,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 7,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<1, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 8,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<1, 0, 0, 1>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 0, 0>>,l |-> 9,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<1, 0, 1, 1>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<1>>, <<>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 1, 0>>,l |-> 10,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<1, 0, 0, 1>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<>>, <<>>, <<1>>, <<1>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<0, 0, 1, 1>>,l |-> 11,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<1, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<1>>, <<>>, <<1>>, <<1>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<1, 0, 1, 1>>,l |-> 12,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, FALSE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "NORMAL", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, leader |-> 1, type |-> "COMPLAINT", sender |-> 3], [view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<1>>, <<>>, <<1>>, <<1>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<1, 0, 1, 1>>,l |-> 12,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, TRUE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "VC_STARTED", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<1>>, <<>>, <<1>>, <<1>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<1, 0, 1, 1>>,l |-> 12,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, TRUE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>]),
    ([phase |-> <<"NORMAL", "NORMAL", "VC_STARTED", "NORMAL">>,vc_delivered_seq |-> <<0, 0, 0, 0>>,msgs |-> {[type |-> "VIEW_CHANGE", sender |-> 3, next_view |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 1, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 3, digest |-> 1], [view |-> 0, seq |-> 1, type |-> "PREPARE", sender |-> 4, digest |-> 1]},ctrl_updating |-> <<FALSE, FALSE, FALSE, FALSE>>,commit_votes |-> <<(0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {1, 2, 3, 4} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_chg_pend |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_start_dropped |-> <<FALSE, FALSE, FALSE, FALSE>>,log |-> <<<<1>>, <<>>, <<1>>, <<1>>>>,blacklist |-> <<{}, {}, {}, {}>>,ctrl_decisions |-> <<1, 0, 1, 1>>,l |-> 13,hbm_role |-> <<"LEADER", "FOLLOWER", "FOLLOWER", "FOLLOWER">>,prepare_votes |-> <<(0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {}), (0 :> {} @@ 1 :> {} @@ 2 :> {} @@ 3 :> {} @@ 4 :> {} @@ 5 :> {} @@ 6 :> {} @@ 7 :> {} @@ 8 :> {} @@ 9 :> {} @@ 10 :> {})>>,hbm_timed_out |-> <<FALSE, FALSE, TRUE, FALSE>>,hbm_artif_pending |-> <<FALSE, FALSE, FALSE, FALSE>>,vc_view |-> <<0, 0, 0, 0>>,vc_quorum |-> <<{}, {}, {}, {}>>,ctrl_view_pending |-> <<0, 0, 0, 0>>,ctrl_view |-> <<0, 0, 0, 0>>,committed_during_vc |-> <<0, 0, 0, 0>>,hbm_view |-> <<0, 0, 0, 0>>,in_flight |-> <<0, 0, 0, 0>>])
    >>
----


=============================================================================

---- CONFIG Trace_TTrace_1781298753 ----
CONSTANTS
    Server = { 1 , 2 , 3 , 4 }
    F = 1
    Quorum = 3
    Byzantine = { }
    NodesList <- MCNodesList
    DecisionsPerLeader = 2
    LeaderRotation = FALSE
    MaxView = 10
    MaxSeq = 10
    NULL = 0

INVARIANT
    _inv

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Fri Jun 12 23:12:34 CEST 2026