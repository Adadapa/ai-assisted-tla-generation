# Modeling Brief: hyperledger-labs/SmartBFT

## 1. System Overview

- **System**: hyperledger-labs/SmartBFT — Go BFT consensus library used by Hyperledger Fabric orderers
- **Language**: Go, ~4,800 LOC core logic (`internal/bft/`)
- **Protocol**: SmartBFT — PBFT-family view-change with rotating-leader extension (HotStuff-style leader rotation within a view)
- **Category**: **Category A (Distributed / Message-Passing)** — network RPC, protocol state machines, crash recovery, BFT adversary. BFT overlay applies.
- **Key architectural choices**:
  - **HeartbeatMonitor** runs in an **independent goroutine** separate from the Controller and ViewChanger; makes failure-detection decisions with its own (potentially stale) view state
  - **Leader rotation within a view**: leader identity is a function of `(view, decisionsInView, blacklist)` — not just `view`; multiple components must stay in sync on this triple
  - **ViewChanger** is a fully separate goroutine with its own run loop, communicating with the Controller via channels; view-change and normal-path decisions can race on shared Checkpoint state
  - **MutuallyExclusiveDeliver** wrapper serializes all delivery paths (added via commit `57f434c` after several double-delivery bugs)
  - **Dual delivery interfaces**: Controller uses `c.Deliver` (wrapped); ViewChanger uses `v.Application` (also wrapped since PR #570); `syncLock` guards concurrent sync+view-change delivery
- **Concurrency model**: Three concurrent subsystems — Controller run loop, ViewChanger run loop, HeartbeatMonitor goroutine — communicating via buffered/unbuffered channels

**BFT Layer** (per `bft-analysis.md`):
- Corruption type: static (`f < N/3`)
- Network model: partial-synchronous (post-GST)
- Authentication: authenticated channels with unforgeable signatures
- Threshold: `N ≥ 3f+1`

---

## 2. Bug Families

### Family 1: Heartbeat Monitor State Isolation (HIGH)

**Mechanism**: The HeartbeatMonitor goroutine makes failure-detection decisions (fire `OnHeartbeatTimeout`, trigger `Sync`) based on its own `hm.view`, `hm.timedOut`, and `hbRespCollector` state, which can diverge from the Controller's view state due to channel ordering. Multiple independent sub-bugs share this root.

**Evidence**:
- Historical: commit `cb0a41b` (PR #502) — leader stops sending heartbeat after view change; HBM not reset (fixed)
- Code analysis: `heartbeatmonitor.go:379` — `followerTick` short-circuits when `hm.timedOut == true`; this flag is only cleared by a `ChangeRole` command (`handleCommand` at line 346). Once the first `OnHeartbeatTimeout` fires per view, **no further complaints are possible** until a role change arrives. If the first complaint fails to produce a view change (e.g., stalled quorum), the follower permanently stops detecting the dead leader.
- Code analysis: `heartbeatmonitor.go:152–160` — `InjectArtificialHeartbeat` uses a capacity-1 channel with `default` drop. During proposal bursts, artificial heartbeats are silently dropped. Followers whose last-real-heartbeat timestamp is stale can fire `OnHeartbeatTimeout` against a live, actively-proposing leader, triggering spurious view changes.
- Code analysis: `heartbeatmonitor.go:271–284` — `hbRespCollector` triggers leader-side sync when `len(map) >= f+1`, but the comment says "f+1 identical." The map counts distinct senders regardless of whether their reported views agree. A heterogeneous set of f+1 views (e.g., 2 at view 5, 1 at view 7) triggers sync prematurely.
- Code analysis: `heartbeatmonitor.go:228–231` — if `hb.View > hm.view`, `Sync()` is called immediately. Since `hm.view` is updated only when a `ChangeRole` command is drained, a ChangeRole in flight causes all new-leader heartbeats to look like "future view" heartbeats, triggering spurious sync.

**Affected code paths**:
- `HeartbeatMonitor.followerTick()` (heartbeatmonitor.go:378–406)
- `HeartbeatMonitor.InjectArtificialHeartbeat()` (heartbeatmonitor.go:152–160)
- `HeartbeatMonitor.HandleHeartbeatResponse()` (heartbeatmonitor.go:263–295)
- `HeartbeatMonitor.handleHeartBeat()` (heartbeatmonitor.go:219–249)

**Suggested modeling approach**:
- Variables: `hbm_view [Server]`, `hbm_timed_out [Server -> Bool]`, `hbm_last_heartbeat [Server -> Nat]`, independent from `currView` in Controller
- Actions: Separate `HBMonitorTick` action (fires independently of consensus round); `InjectArtificialHeartbeat` as a non-atomic conditional update (models drop); `ChangeRole` as a separate event that resets `hbm_timed_out` and `hbm_view`
- The key invariant: `hbm_timed_out[s] => ~ LeaderAlive` should hold (false heartbeat timeouts are not possible); investigate whether `timedOut` suppression and artificial-heartbeat drops can violate this

**Priority**: High
**Rationale**: `timedOut` suppression and artificial-heartbeat drops are both active in current HEAD. The independent HBM goroutine is a deliberate architectural choice analogous to the Hashicorp-Raft heartbeat goroutine that was the root cause of Family 1 there. Three distinct sub-bugs share the same root (stale HBM state), indicating more lurking.

---

### Family 2: View-Change Delivery Before Outer Validation (HIGH)

**Mechanism**: In view-change recovery paths, a node delivers a decision to the application *before* verifying the outer `SignedViewData` envelope signature. If the outer signature fails, the function returns `false` (message invalid), causing the ViewData not to count toward quorum — but the sequence has already advanced. The node is stuck at the new sequence without a completed view change.

**Evidence**:
- Code analysis: `viewchanger.go:617–665` — `checkLastDecision`: `v.deliverDecision(proposal, signatures)` at line 640, then `VerifySignature` at line 660. If the outer sig check fails (line 661–662), returns `false, 0` — the ViewData entry doesn't contribute to view-change quorum, but the sequence was delivered.
- Code analysis: `viewchanger.go:1067–1082` — `validateNewViewMsg`: same pattern. `v.deliverDecision` at line 1067, then `VerifySignature` at line 1075. On signature failure, returns `false, false, false` — subtracts one from the effective quorum count.
- The comment at `viewchanger.go:650` acknowledges the ordering: "if there was a delivery with a reconfig we need to stop here before verify signature" — the ordering is intentional for reconfiguration cases, but the outer envelope signature check is not.
- Context: `v.Application` is `MutuallyExclusiveDeliver` (set in `consensus.go:440`), so `deliverDecision` does update the Checkpoint. This prevents double-delivery on re-entry. The harm is specifically to view-change liveness: quorum is one short.

**Affected code paths**:
- `ViewChanger.checkLastDecision()` (viewchanger.go:559–666)
- `ViewChanger.validateNewViewMsg()` (viewchanger.go:975–1095)

**Suggested modeling approach**:
- Variables: `delivered_sequence [Server]`, `view_change_quorum [Server -> Nat]` separate from `committed_sequence [Server]`
- Actions: Model the "deliver then validate" as two sub-steps within `ProcessViewData`; Byzantine node can present valid inner decision + invalid outer signature
- Invariant: `view_change_quorum[s] >= quorum => EntersNewView[s]` should hold regardless of Byzantine message crafting

**Priority**: High
**Rationale**: Open finding in current HEAD. Under a Byzantine adversary targeting this path, a correct node can be forced to advance its sequence without completing view change, causing it to fall out of sync with the view-change quorum. Liveness violation under Byzantine conditions.

---

### Family 3: DecisionsInView / Leader Identity Consistency (HIGH)

**Mechanism**: Leader identity in SmartBFT is a function of `(view, decisionsInView, blacklist)`. Multiple independent components maintain their own copies of `decisionsInView` and can diverge, computing different leaders and triggering spurious view changes.

**Evidence**:
- Historical: commit `62e7161` (PR #663, Apr 2026) — `DecisionsInView` reset to 0 on same-height sync; passed to `changeView`, causing the next proposal to fail validation at `view.go:577` with "Expected decisions in view 0 but got N" → recovery sync loop → orderers permanently fall behind. Production impact: witnessed weekly.
- Historical: commit `2d10ba0` — wrong leader blacklist offset + wrong AuxiliaryData field; both affect the leader identity computation. Fixed but the complexity of the triple `(view, decisionsInView, blacklist)` persists.
- Code analysis: `controller.go:121–125, 407–430` — `currViewNumber` and `currDecisionsInView` are protected by two separate `sync.RWMutex` objects. In `changeView`, they are updated in sequence: `setCurrentViewNumber` then `setCurrentDecisionsInView`. Between these two calls, concurrent `ProcessMessages` callers invoking `leaderID()` (which reads both) see the new view number with the old decisions count, computing a transiently wrong leader.
- Code analysis: `viewchanger.go:231–233` — `ViewChanger.getLeader()` always passes `decisionsInView=0` to `getLeaderID`. This is correct for new-view entry (new view starts decisions=0), but confirms that the ViewChanger has no channel to learn the in-view decisions count — it relies entirely on `currView` being set correctly.

**Affected code paths**:
- `Controller.changeView()` (controller.go:407–430)
- `Controller.leaderID()` (controller.go:234)
- `Controller.sync()` (controller.go:601–700) — the `newDecisionsInView` update
- `ViewChanger.getLeader()` (viewchanger.go:231–233)

**Suggested modeling approach**:
- Variables: `controller_view [Server]`, `controller_decisions [Server]`, `hbm_view [Server]` — three separate view-tracking variables per server, updated at different times
- Model `leaderID` as a pure function of these inputs
- Key action: `ChangeView` must atomically update both `controller_view` and `controller_decisions`; current code does not
- Invariant: `AllNodesSeeLeader(view, decisions)` — for any given (view, decisions) pair, all nodes agree on leader identity

**Priority**: High
**Rationale**: Recently-fixed production bug shows this mechanism is still actively failing in the wild. The non-atomic two-lock update is an unaddressed finding in current HEAD. The triple `(view, decisions, blacklist)` for leader identity is SmartBFT-specific and not covered by standard BFT specs.

---

### Family 4: Sync–ViewChange Delivery Sequencing (HISTORICAL / REFERENCE)

**Mechanism**: When async sync and view-change delivery paths run concurrently, the same proposal can be delivered to the application twice (or not at all).

**Evidence**:
- Historical: commits `57f434c`, `d9182ed`, `0ac141d`, `154c866`/`31f018a` — four independently found variants of the same bug; 3 of them are CRITICAL (safety violations). This area had multiple PRs and a revert.
- Root causes spanned: missing checkpoint update, missing `syncLock`, missing `maybePruneInFlight`, genesis edge case (sequence 0 comparison).
- Current state: **Fixed** by `MutuallyExclusiveDeliver` wrapper + `syncLock` mutex architecture.
- Value as reference: These bugs demonstrate that the Sync × ViewChange interaction is the highest bug-density region in the codebase. Any spec that models both must be extremely careful about their interleaving.

**Priority**: Reference (fixed, high historical weight)

---

### Family 5: In-Flight Proposal Lifecycle (HIGH, PARTIALLY FIXED)

**Mechanism**: The in-flight proposal mechanism (tracking proposals that may have been decided at some nodes during view change) has historically had multiple logic errors. The `CheckInFlight` function determines whether to replay a proposal — bugs here can cause safety violations (skip a decided proposal) or livelock (never declare no-in-flight).

**Evidence**:
- Historical: commit `420a802` — `CheckInFlight` condition B (no prepared in-flight) never returned true because counter was never incremented. Liveness failure: view change stalls when no in-flight.
- Historical: commit `30764c3` — panic when second ViewData arrives after committing during view change (in-flight sequence lag).
- Historical: commit `0ac141d` — stale in-flight retained after sync; causes double-delivery attempts on subsequent view changes.
- Code analysis: `viewchanger.go:492–497` — `committedDuringViewChange` is never reset between view changes. If a node commits during view change N→N+1 but not during N+1→N+2, the stale `committedDuringViewChange` from the first change incorrectly suppresses in-flight reporting during the second.
- Code analysis: `viewchanger.go:356–361` — `StartViewChange` (external entry point) uses `select { default: }` on a capacity-2 channel. If the heartbeat monitor, request timeout handler, and a concurrent message all call `StartViewChange` within the same scheduling window, excess calls are silently dropped. The node never triggers view change.

**Affected code paths**:
- `CheckInFlight()` (viewchanger.go:814–908)
- `ViewChanger.getInFlight()` (viewchanger.go:468–499)
- `ViewChanger.StartViewChange()` (viewchanger.go:356–361)
- `ViewChanger.committedDuringViewChange` field (line 109, 492–497, 648)

**Suggested modeling approach**:
- Variables: `in_flight [Server -> Option(Proposal)]`, `committed_during_vc [Server -> Option(Seq)]`
- Model `StartViewChange` as non-deterministic drop (can succeed or be silently dropped)
- Check: can `committedDuringViewChange` stale state suppress a real in-flight that needs replay?

**Priority**: High
**Rationale**: Two unaddressed findings in current HEAD (`committedDuringViewChange` never reset; `StartViewChange` drop). Historical bug density (4 fixes) is the highest in the codebase. `CheckInFlight` is the primary safety mechanism in view change.

---

## 3. Modeling Recommendations

### 3.1 Model

| What | Why | How |
|------|-----|-----|
| Independent HeartbeatMonitor state | Family 1: `timedOut` suppression + artificial HB drops cause false view-change triggers; HBM view lags Controller view | Separate `hbm_view`, `hbm_timed_out` variables; `HBMonitorTick` action independent of consensus step |
| Deliver-before-validate in view-change | Family 2: under Byzantine adversary, sequence advances without completing view change | Two-step `ProcessViewData`: deliver then validate separately; Byzantine message with valid inner + invalid outer sig |
| Atomic (view, decisionsInView) update | Family 3: non-atomic two-lock update allows transient wrong leader identity | Single action that atomically updates both; concurrent readers observe atomic snapshot |
| Leader identity as computed function | Family 3: triple `(view, decisions, blacklist)` — SmartBFT-specific deviation from standard BFT | `LeaderID = f(view, decisions, blacklist)` in spec; model blacklist as a server set |
| `StartViewChange` silent drop | Family 5: capacity-2 channel with default can cause missed view change trigger | Non-deterministic action: `MaybeStartViewChange` succeeds or is dropped; check liveness under drop |
| `committedDuringViewChange` stale field | Family 5: stale value suppresses in-flight report on second view change | Model as variable that should be reset; check `CheckInFlight` behavior with stale vs reset value |
| Crash and recovery | Foundation: many bugs are crash-window bugs; in-memory vs persisted state divergence | `Crash` action resets volatile state; recover from Checkpoint + WAL |

### 3.2 Do Not Model

| What | Why |
|------|-----|
| Request pool concurrency bugs | All major bugs fixed (`c5a7847`, `79fd150`, `e5e760c`, `86be08d`); better verified with Go race detector |
| Batcher Reset/Close channel race | Implementation-level Go channel race; not protocol logic; test-verifiable |
| WAL truncation policy | Acknowledged TODO (state.go:57); no correctness impact; operational concern only |
| Double delivery via sync (Family 4) | Fixed by MutuallyExclusiveDeliver + syncLock; reproducing this via TLA+ yields no new information |
| `maxLastDecisionSequence` Byzantine inflation | Apparent false positive: Byzantine node cannot present `LastDecision.Sequence = S` without f+1 honest commit signatures, meaning honest nodes also committed S; the max is semantically correct |
| Exact `CheckInFlight` condition B | Already fixed (commit `420a802`); modeling it would reproduce a closed bug |

---

## 4. Proposed Extensions

| Extension | Variables | Purpose | Bug Family |
|-----------|-----------|---------|------------|
| Independent HBM state | `hbm_view[s]`, `hbm_timed_out[s]`, `hbm_last_hb[s]` | Capture HBM state divergence from Controller state | Family 1 |
| Artificial heartbeat drop | `hbm_artificial_pending[s]` | Model capacity-1 drop of InjectArtificialHeartbeat | Family 1 |
| Two-step view-data processing | `vc_delivered_seq[s]`, `vc_quorum_count[s]` separate | Capture deliver-before-validate window | Family 2 |
| Leader identity triple | `controller_view[s]`, `controller_decisions[s]`, `blacklist[s]` | Model non-atomic update of view+decisions; LeaderID as computed function | Family 3 |
| StartViewChange drop | Boolean non-determinism in `MaybeStartViewChange` | Model capacity-2 channel overflow | Family 5 |
| committedDuringViewChange | `committed_during_vc[s]` — set, never cleared | Track stale in-flight suppression across consecutive view changes | Family 5 |

---

## 5. Proposed Invariants

| Invariant | Type | Description | Targets |
|-----------|------|-------------|---------|
| Agreement | Safety | No two correct nodes deliver different decisions at the same sequence | Standard BFT |
| ViewChangeSafety | Safety | If a node enters view V, all earlier view's decided proposals are included in V | Standard BFT |
| NoFalseTimeout | Safety | `hbm_timed_out[s] = true => ~ (leader s is alive and sending proposals)` | Family 1 |
| HeartbeatTimedOutImpliesComplain | Liveness | If leader is dead and `hbm_timed_out[s] = false`, eventually `OnHeartbeatTimeout` fires | Family 1 |
| LeaderIdentityConsistency | Safety | All correct nodes agree on leader(view, decisions, blacklist) | Family 3 |
| DeliverImpliesViewEntered | Safety | If node delivers sequence S and then enters view V, V's leader correctly identifies S as committed | Family 2 |
| InFlightReplay | Safety | If any correct node has sequence S prepared, the new view either re-proposes S or S has been committed by quorum | Family 5 |
| StartViewChangeLiveness | Liveness | If a correct node calls StartViewChange(v), eventually a view change for view v is triggered | Family 5 |

---

## 6. Findings Pending Verification

### 6.1 Model-Checkable

| ID | Description | Expected invariant violation | Bug Family |
|----|-------------|------------------------------|------------|
| MC-1 | If `hbm_timed_out` is never reset within a view (timedOut flag suppression), can a live system with a dead leader permanently stall without triggering a second view change? | HeartbeatTimedOutImpliesComplain (liveness) | Family 1 |
| MC-2 | If artificial heartbeat drops are modeled, can a live leader's proposal burst cause a correct follower to fire `OnHeartbeatTimeout` and trigger a spurious view change? | NoFalseTimeout | Family 1 |
| MC-3 | If `controller_view` and `controller_decisions` are updated non-atomically (separate locks), can a concurrent `leaderID()` read observe a view/decisions combination that maps to a different leader, causing a valid proposal to be incorrectly rejected? | LeaderIdentityConsistency | Family 3 |
| MC-4 | If a Byzantine node sends a ViewData with valid inner decision + invalid outer signature, can a correct node advance sequence (via `deliverDecision`) without the ViewData counting toward view-change quorum, leaving the node stuck at the new sequence? | DeliverImpliesViewEntered, ViewChangeSafety | Family 2 |
| MC-5 | If `committedDuringViewChange` is never reset between consecutive view changes, does a stale value incorrectly suppress in-flight reporting in the second change, potentially causing the new leader to miss a proposal that needs replay? | InFlightReplay | Family 5 |
| MC-6 | If `StartViewChange` can silently drop view-change requests (capacity-2 channel), and multiple simultaneous trigger sources (HBM, request timeout, view-change message) fire together, can the node fail to ever trigger view change against a dead leader? | StartViewChangeLiveness | Family 5 |

### 6.2 Test-Verifiable

| ID | Description | Suggested test approach |
|----|-------------|------------------------|
| TV-1 | `hbRespCollector` triggers sync with heterogeneous views (f+1 senders but different view numbers) | Unit test: send `f+1` heartbeat responses with differing View fields; verify sync is NOT triggered |
| TV-2 | Stale `hm.view` causes spurious `Sync()` when `ChangeRole` command in flight | Race detector test: concurrent `ChangeRole` + incoming heartbeat with new view number |
| TV-3 | `Batcher.Reset()` swaps `closeChan`; in-progress `NextBatch` holds old channel reference; subsequent `Close()` does not unblock it | Unit test: mock timing of Reset → NextBatch → Close; verify NextBatch eventually returns |
| TV-4 | `recoverPrepared` panics if app checkpoint sequence lags WAL sequence | Crash-recovery test with mocked checkpoint that returns sequence N-1 while WAL has N |

### 6.3 Code-Review-Only

| ID | Description | Suggested action |
|----|-------------|-----------------|
| CR-1 | `heartbeatmonitor.go:346` — `timedOut` reset inside `handleCommand` only; should also consider re-arming after timeout if view change quorum not reached | File issue; discuss whether a re-arm timeout (e.g., 2× view-change timeout) is safe |
| CR-2 | `viewchanger.go:407–410` — WAL saves `NextView: v.currView` (old view) instead of `NextView: v.nextView`. Impact unclear (restore path uses `v.currView` at the time of restore, not the stored value) | Investigate restore path; fix if `NextView` field is ever used on recovery |
| CR-3 | `viewchanger.go:393–404` — `startViewChange` called twice on non-SpeedUp path; `AbortView` called twice | Code review; confirm no double-abort effect in Controller |
| CR-4 | `view.go:447–462` — prepare messages accepted without verifying inner `prepare.View` and `prepare.Seq` match current view/sequence (only digest checked) | File issue; add inner-field validation |
| CR-5 | `view.go:538–542` — commit signature goroutines have no cancellation when view aborts; goroutine leak under high view-change frequency | Audit with goroutine tracking test |

---

## 7. Reference Pointers

- **Full analysis report**: `.specula-output/analysis-report.md`
- **Key source files**:
  - `internal/bft/viewchanger.go` (1363 lines) — view-change protocol, `CheckInFlight`, `deliverDecision`
  - `internal/bft/controller.go` (977 lines) — main state machine, `changeView`, `MutuallyExclusiveDeliver`
  - `internal/bft/view.go` (1093 lines) — per-round PBFT state machine, prepare/commit vote sets
  - `internal/bft/heartbeatmonitor.go` (414 lines) — failure detection, leader/follower role separation
  - `internal/bft/state.go` (247 lines) — WAL persistence, crash recovery
  - `internal/bft/util.go` (574 lines) — `getLeaderID`, `CheckInFlight`, vote set primitives
- **Key GitHub issues/PRs**: #663 (DecisionsInView reset), #622 (deadlock), #570 (double delivery), #499 (fork VC), #484/#553 (double delivery variants), #538 (in-flight panic), #502 (HBM not reset)
- **Protocol reference**: SmartBFT paper (Bessani et al., Hyperledger project docs)
- **SmartBFT wiki**: https://github.com/hyperledger-labs/SmartBFT/wiki (describes protocol, view change)
